# HYDRA LEARNINGS

> *Accumulated wisdom from building and operating Hydra*

This document captures insights, patterns, gotchas, and lessons learned. Claude Code should consult this when encountering similar situations and add new learnings after significant discoveries.

---

## How to Use This Document

**Reading:** Before attempting something complex, search this document for related keywords.

**Writing:** After resolving a non-trivial issue or discovering something useful, add an entry:
```markdown
### [Short Title]
**Date:** YYYY-MM-DD
**Context:** What you were trying to do
**Learning:** What you discovered
**Application:** How to apply this in the future
```

---

## Infrastructure Learnings

### ExLlamaV2 is the Only Option for Heterogeneous Tensor Parallelism
**Date:** 2025-12-09
**Context:** Trying to run 70B models across RTX 5090 (32GB) + RTX 4090 (24GB)
**Learning:** ExLlamaV2 + TabbyAPI is the only inference engine that supports tensor parallelism across GPUs with different VRAM sizes. vLLM, Aphrodite, and ExLlamaV3 all require matching GPU configurations.
**Application:** Always use ExLlamaV2 for the 5090+4090 setup. Don't waste time trying vLLM or other engines for this use case.

### 10GbE Changes Everything
**Date:** 2025-12-09
**Context:** Model loading times were frustrating development iteration
**Learning:** With 10GbE backbone achieving 1.1 GB/s NFS throughput, model loading dropped from 5+ minutes to ~30 seconds for 70B models. This transforms the development experience.
**Application:** Always complete network layer before optimizing other things. Fast iteration beats perfect optimization.

### NixOS Atomic Rollbacks are a Superpower
**Date:** 2025-12-08
**Context:** Broke CUDA configuration during driver update
**Learning:** `nixos-rebuild switch --rollback` instantly restored working state. No debugging required.
**Application:** On NixOS nodes, be aggressive with changes. Rollback is cheap. On Unraid (no atomic rollback), be more conservative.

### Unraid Docker vs NixOS Services
**Date:** 2025-12-07
**Context:** Deciding where to run services
**Learning:** 
- **Unraid Docker:** Better for always-on services, databases, things that need persistent storage. Web UI for manual intervention.
- **NixOS systemd:** Better for GPU services, things that need to restart cleanly, reproducible configuration.
**Application:** 
- Databases, orchestration, media → hydra-storage (Unraid)
- Inference, creative tools → hydra-ai/compute (NixOS)

### CUDA Version Mismatches are Silent Killers
**Date:** 2025-12-09
**Context:** TabbyAPI crashed with cryptic errors
**Learning:** PyTorch, ExLlamaV2, and CUDA driver versions must all be compatible. Blackwell GPUs (5090) need CUDA 12.8+. Check nvidia-smi first, then verify PyTorch CUDA version.
**Application:** When inference fails, first check: `nvidia-smi` (driver), `python -c "import torch; print(torch.version.cuda)"` (PyTorch CUDA).

---

## Operational Learnings

### Health Checks Need Timeouts
**Date:** 2025-12-08
**Context:** Health check script hung indefinitely when service was in bad state
**Learning:** Always use `--max-time` with curl: `curl -s --max-time 5 http://service/health`
**Application:** All health check commands should have 3-5 second timeouts.

### SSH Connection Reuse Speeds Everything Up
**Date:** 2025-12-07
**Context:** Running multiple SSH commands to same host was slow
**Learning:** SSH ControlMaster allows connection reuse:
```
# ~/.ssh/config
Host hydra-*
  ControlMaster auto
  ControlPath ~/.ssh/sockets/%r@%h-%p
  ControlPersist 600
```
**Application:** Ensure SSH config is set up on any machine running Claude Code.

### Log Locations Matter
**Date:** 2025-12-06
**Context:** Debugging service failure with no obvious errors
**Learning:**
- NixOS services: `journalctl -u service-name -f`
- Docker containers: `docker logs container-name -f`
- TabbyAPI: stdout in journalctl
- ComfyUI: stdout + `~/.comfyui/comfyui.log`
**Application:** First debug step is always checking logs in the right place.

---

## Model Learnings

### EXL2 Quantization Quality vs Size
**Date:** 2025-12-05
**Context:** Choosing quantization level for 70B model
**Learning:**
- 3.5bpw: Fits in 56GB VRAM with room for context, minimal quality loss
- 4.0bpw: Higher quality but tighter fit
- 2.5bpw: Noticeable quality degradation, only for fitting larger models
**Application:** Default to 3.5bpw for 70B models on this setup. Go to 4.0bpw only if quality issues observed.

### Model Loading Order Matters
**Date:** 2025-12-06
**Context:** TabbyAPI failed to load model after ComfyUI loaded diffusion model
**Learning:** GPU VRAM is first-come-first-served. Load large LLMs before starting image generation services.
**Application:** Service startup order: TabbyAPI → Ollama → ComfyUI

### Context Window vs VRAM Tradeoff
**Date:** 2025-12-05
**Context:** Running out of VRAM mid-conversation
**Learning:** With tensor parallelism, context uses VRAM on both GPUs. 8K context is safe. 16K possible but tight. 32K will OOM.
**Application:** Configure TabbyAPI with `expect_cache_tokens` based on expected context size. Don't promise more than 16K context.

---

## Creative Pipeline Learnings

### ComfyUI API Workflow
**Date:** 2025-12-04
**Context:** Automating image generation
**Learning:**
1. Export workflow from UI as `workflow_api.json` (not regular `workflow.json`)
2. POST to `/prompt` endpoint with workflow JSON
3. Poll `/history/{prompt_id}` for completion
4. Images saved to output directory with predictable naming
**Application:** Always export API format. Regular workflow format won't work with API.

### Character Consistency Techniques
**Date:** 2025-12-04
**Context:** Generating consistent character across multiple images
**Learning:**
- **Best:** Train LoRA with 15-30 reference images (1500-3000 steps)
- **Good:** IP-Adapter with face reference image
- **Quick:** InstantID for face-only consistency
- **Combine:** LoRA for body/style + InstantID for face
**Application:** For Empire of Broken Queens, train LoRAs for main queens, use InstantID for NPCs.

### TTS Voice Matching
**Date:** 2025-12-03
**Context:** Generating character voices
**Learning:**
- Kokoro: Fast (210x realtime) but limited voice control
- F5-TTS: Zero-shot cloning from seconds of audio
- Best workflow: Generate sample with F5-TTS from voice reference, use that for consistent voice
**Application:** Create voice reference clips for each queen, use F5-TTS for cloning consistency.

---

## Agent/Automation Learnings

### n8n Webhook Reliability
**Date:** 2025-12-08
**Context:** Alerts not triggering workflows
**Learning:** n8n webhooks can miss events if n8n restarts during delivery. Use Redis queue for critical alerts.
**Application:** For self-healing workflows, push alerts to Redis first, then have n8n poll Redis.

### Rate Limiting Remediation
**Date:** 2025-12-07
**Context:** Service restart loop
**Learning:** Without rate limiting, a flapping service can trigger remediation repeatedly, making things worse. 
**Application:** Always implement: max 3 remediations per hour per service, exponential backoff, human escalation after failures.

---

## Working with Claude Code Learnings

### Context Window Management
**Date:** 2025-12-10
**Context:** Long sessions losing early context
**Learning:** Claude Code has limited context. For long sessions:
- Update STATE.json frequently
- Add learnings to this file
- Reference documents by filename rather than including content
**Application:** At natural breakpoints, persist state to files.

### Batch Commands for Efficiency
**Date:** 2025-12-09
**Context:** Many small operations taking too long
**Learning:** Chain commands with `&&` for efficiency. Claude Code can run batches:
```bash
ssh host "cmd1 && cmd2 && cmd3"
```
**Application:** Prefer consolidated commands over many small ones.

### NixOS Rebuild Strategy
**Date:** 2025-12-08
**Context:** Testing NixOS configuration changes
**Learning:** 
- `nixos-rebuild test`: Activates config but doesn't make it boot default
- `nixos-rebuild switch`: Makes it permanent
- `nixos-rebuild build`: Just builds, doesn't activate (safe to verify)
**Application:** Use `build` first to catch errors, then `switch` when confident.

---

## Adding New Learnings

When Claude Code discovers something worth remembering:

1. Identify the category (Infrastructure, Operational, Model, Creative, Agent, Claude Code)
2. Add entry with Date, Context, Learning, Application
3. Keep entries concise but complete
4. Cross-reference other documents if relevant

**Template:**
```markdown
### [Descriptive Title]
**Date:** YYYY-MM-DD
**Context:** What situation led to this discovery
**Learning:** The key insight or fact discovered
**Application:** How to use this knowledge in the future
```

---

*This document grows with experience. Consult it before repeating mistakes.*
*Last updated: December 2025*
