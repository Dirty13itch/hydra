# HYDRA - AUTONOMOUS AI OPERATING SYSTEM

> *"An AI that learns, remembers, and proactively serves its human."*

---

## 🚀 SESSION BOOTSTRAP

**Execute these steps automatically at the start of every session:**

### Step 1: Load Context (Read These Files)
```
Required reading (in order):
1. STATE.json         → Current system state, tasks, issues
2. ROADMAP.md         → Current phase, what to work on
3. LEARNINGS.md       → Past insights relevant to today's work
4. ARCHITECTURE.md    → How things connect (reference as needed)
5. VISION.md          → The north star (reference for big decisions)
```

### Step 2: Quick Health Check
Run this batch command to verify cluster status:
```bash
# Ping all nodes
ping -c1 -W2 192.168.1.250 && echo "✓ hydra-ai" || echo "✗ hydra-ai DOWN"
ping -c1 -W2 192.168.1.203 && echo "✓ hydra-compute" || echo "✗ hydra-compute DOWN"
ping -c1 -W2 192.168.1.244 && echo "✓ hydra-storage" || echo "✗ hydra-storage DOWN"

# Check key services (5s timeout each)
curl -s --max-time 5 http://192.168.1.250:5000/health >/dev/null 2>&1 && echo "✓ TabbyAPI" || echo "✗ TabbyAPI"
curl -s --max-time 5 http://192.168.1.250:4000/health >/dev/null 2>&1 && echo "✓ LiteLLM" || echo "✗ LiteLLM"
curl -s --max-time 5 http://192.168.1.203:8188/ >/dev/null 2>&1 && echo "✓ ComfyUI" || echo "✗ ComfyUI"
```

### Step 3: Report Status
Provide a brief summary:
- 🟢 What's healthy
- 🔴 What's down (investigate if unexpected)
- 📋 Current phase and top priority from ROADMAP.md
- 💡 Suggest what to work on OR ask for direction

### Step 4: Work Aligned with Vision
All work should advance toward the autonomous AI operating system described in VISION.md. Reference ROADMAP.md to stay on track.

---

## SYSTEM OVERVIEW

### The Three Nodes

| Node | IP | Role | OS | SSH |
|------|-----|------|-----|-----|
| hydra-ai | 192.168.1.250 | Inference (5090+4090, 56GB VRAM) | NixOS | `ssh shaun@192.168.1.250` |
| hydra-compute | 192.168.1.203 | Creative (5070Ti+3060, 28GB VRAM) | NixOS | `ssh shaun@192.168.1.203` |
| hydra-storage | 192.168.1.244 | Control Plane (EPYC, 256GB RAM) | Unraid | `ssh root@192.168.1.244` |

### Key Services

| Service | Location | Port | Purpose |
|---------|----------|------|---------|
| TabbyAPI | hydra-ai | 5000 | Primary inference (70B models) |
| LiteLLM | hydra-ai | 4000 | API gateway/router |
| Ollama | hydra-ai | 11434 | Backup inference |
| ComfyUI | hydra-compute | 8188 | Image generation |
| Ollama | hydra-compute | 11434 | Embeddings, draft models |
| PostgreSQL | hydra-storage | 5432 | State database |
| Qdrant | hydra-storage | 6333 | Vector store |
| n8n | hydra-storage | 5678 | Workflow automation |
| Prometheus | hydra-storage | 9090 | Metrics |
| Grafana | hydra-storage | 3003 | Dashboards |

### Storage Mounts

```
hydra-storage exports:
  /mnt/user/models       → NFS mounted to /mnt/models on NixOS nodes
  /mnt/user/hydra_shared → NFS mounted to /mnt/shared on NixOS nodes
```

---

## WORKING STYLE

### Autonomy Preferences

**Shaun prefers:**
- ✅ Autonomous execution - batch commands, chain with `&&`
- ✅ Assume success unless errors occur
- ✅ Don't ask permission for each step - just do it and report
- ✅ "Done right over done fast" - plan before executing
- ✅ Bleeding-edge tech - high appetite for experimental approaches
- ❌ Don't ask clarifying questions when you can make reasonable assumptions
- ❌ Don't explain basics - assume technical competence

### Command Patterns

**Preferred:**
```bash
# Batch commands on remote host
ssh shaun@192.168.1.250 "cmd1 && cmd2 && cmd3"

# Check then act
ssh host "systemctl status service || sudo systemctl restart service"

# With timeout
timeout 30 ssh host "long-running-command"
```

**Avoid:**
```bash
# Don't do one command at a time
ssh host "cmd1"
# wait for approval
ssh host "cmd2"
# wait for approval
ssh host "cmd3"
```

### NixOS vs Unraid

**NixOS nodes (hydra-ai, hydra-compute):**
- Configuration is declarative in `/etc/nixos/`
- Services managed by systemd
- Changes via `nixos-rebuild switch`
- Rollback available: `nixos-rebuild switch --rollback`
- Be more aggressive - rollback is cheap

**Unraid (hydra-storage):**
- Services run as Docker containers
- Managed via docker-compose or Unraid UI
- No atomic rollback - be more careful
- Container data in `/mnt/user/appdata/`

---

## DOCUMENT SYSTEM

### Document Hierarchy

```
VISION.md          WHY - The north star, end state, principles
     ↓
ARCHITECTURE.md    HOW - Technical blueprint, how things connect
     ↓
ROADMAP.md         WHAT - Phased plan, milestones, tasks
     ↓
STATE.json         WHERE - Current state, active tasks, issues
     ↓
LEARNINGS.md       WISDOM - Accumulated insights and patterns
```

### How to Use Documents

| Document | When to Read | When to Update |
|----------|--------------|----------------|
| VISION.md | Big decisions, feeling lost | Major vision changes only |
| ARCHITECTURE.md | Understanding connections | When architecture changes |
| ROADMAP.md | Choosing what to work on | When completing milestones |
| STATE.json | Every session start | After any state change |
| LEARNINGS.md | Before complex tasks | After significant discoveries |

### Keeping Documents in Sync

**After completing work:**
1. Update `STATE.json` - mark tasks complete, update service status
2. Add to `LEARNINGS.md` if you discovered something reusable
3. Update `ROADMAP.md` task checkboxes

**Example STATE.json update after fixing a service:**
```json
{
  "nodes": {
    "hydra-ai": {
      "services": {
        "tabbyapi": {
          "status": "running",  // was "degraded"
          "notes": "Fixed CUDA mismatch on 2025-12-10"
        }
      }
    }
  },
  "history": [
    {
      "timestamp": "2025-12-10T15:30:00Z",
      "event": "Fixed TabbyAPI CUDA mismatch",
      "actor": "claude-code",
      "details": "Rebuilt exllamav2 with CUDA 12.8"
    }
  ]
}
```

---

## KNOWLEDGE BASE

### Additional Documentation

The `knowledge/` directory contains domain-specific documentation:

| File | Contents |
|------|----------|
| infrastructure.md | Hardware specs, network topology, ports |
| inference-stack.md | TabbyAPI, LiteLLM, Ollama configuration |
| databases.md | PostgreSQL, Qdrant, Redis setup |
| observability.md | Prometheus, Grafana, Loki, alerting |
| automation.md | n8n workflows, self-healing |
| creative-stack.md | ComfyUI, TTS, image generation |
| media-stack.md | *arr apps, Plex, Stash |
| models.md | Available models, quantization, performance |

**Consult these when working in specific domains.**

---

## SELF-IMPROVEMENT LOOP

Claude Code should continuously improve the system by:

### 1. Learning from Experience
After resolving issues or discovering patterns, add to `LEARNINGS.md`:
```markdown
### [What You Learned]
**Date:** YYYY-MM-DD
**Context:** What situation led to this
**Learning:** The key insight
**Application:** How to apply this in future
```

### 2. Maintaining Accurate State
Keep `STATE.json` reflecting reality:
- Update service status after changes
- Mark tasks complete
- Add history entries for significant events
- Note new issues discovered

### 3. Advancing the Roadmap
Work should align with current phase in `ROADMAP.md`:
- Check boxes as tasks complete
- Note blockers discovered
- Suggest roadmap adjustments if needed

### 4. Expanding Knowledge
When encountering undocumented areas:
- Add to appropriate `knowledge/*.md` file
- Or create new knowledge file if needed
- Cross-reference from other documents

---

## QUICK REFERENCE

### SSH Shortcuts
```bash
alias hai="ssh shaun@192.168.1.250"      # hydra-ai
alias hac="ssh shaun@192.168.1.203"      # hydra-compute
alias has="ssh root@192.168.1.244"       # hydra-storage
```

### Common Operations

**Restart NixOS service:**
```bash
ssh shaun@192.168.1.250 "sudo systemctl restart tabbyapi"
```

**Restart Docker container:**
```bash
ssh root@192.168.1.244 "docker restart container-name"
```

**Check GPU status:**
```bash
ssh shaun@192.168.1.250 "nvidia-smi --query-gpu=name,memory.used,utilization.gpu --format=csv"
```

**View service logs:**
```bash
# NixOS
ssh shaun@192.168.1.250 "journalctl -u tabbyapi -n 50"

# Docker
ssh root@192.168.1.244 "docker logs container-name --tail 50"
```

**NixOS rebuild:**
```bash
ssh shaun@192.168.1.250 "sudo nixos-rebuild switch"
```

**NixOS rollback:**
```bash
ssh shaun@192.168.1.250 "sudo nixos-rebuild switch --rollback"
```

### Model Loading

TabbyAPI model switch (via API):
```bash
curl -X POST http://192.168.1.250:5000/v1/model/load \
  -H "Content-Type: application/json" \
  -d '{"model_name": "Llama-3.1-70B-EXL2-3.5bpw"}'
```

---

## CURRENT PRIORITIES

**Check STATE.json for the authoritative task list.**

High-level priorities (Phase 8 - Memory Layer):
1. Deploy Letta for persistent memory
2. Initialize core memory blocks
3. Connect Letta to LiteLLM
4. Test memory persistence

---

## REMEMBER

- **Autonomy:** Execute, don't ask permission for routine operations
- **Alignment:** All work serves the VISION of autonomous AI OS
- **Documentation:** Keep state synchronized with reality
- **Learning:** Capture insights for future sessions
- **Quality:** Right over fast, but don't over-engineer

---

*This file bootstraps every Claude Code session. Keep it accurate and actionable.*
*Last updated: December 2025*
