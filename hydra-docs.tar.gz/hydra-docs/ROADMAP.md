# HYDRA ROADMAP

> *Phased journey from homelab to autonomous AI operating system*

---

## Current Position

Based on the Phase 7 completion (infrastructure deployed), Hydra is now transitioning from **"running services"** to **"intelligent autonomy"**.

```
COMPLETED                          CURRENT                           FUTURE
─────────────────────────────────────────────────────────────────────────────
                                      │
Phase 1: Network        ████████████  │
Phase 2: Storage        ████████████  │
Phase 3: Databases      ████████████  │
Phase 4: Observability  ████████████  │
Phase 5: Inference      ████████████  │
Phase 6: Automation     ████████████  │
Phase 7: Creative       ████████████  │
                                      │
Phase 8: Memory         ░░░░░░░░░░░░ ◄┘  ← YOU ARE HERE
Phase 9: Agents         ░░░░░░░░░░░░
Phase 10: Control Plane ░░░░░░░░░░░░
Phase 11: Evolution     ░░░░░░░░░░░░
```

---

## Phase 8: Memory Layer (Weeks 1-3)

**Objective:** Give Hydra persistent memory that survives sessions and accumulates knowledge.

### Week 1: Letta Deployment

- [ ] **Deploy Letta on hydra-storage**
  ```bash
  # Docker compose for Letta
  docker-compose -f docker-compose.memory.yml up -d letta
  ```
  - Port: 8283
  - Backend: PostgreSQL (existing)
  - Vector store: Qdrant (existing)

- [ ] **Configure Letta → LiteLLM connection**
  - Letta uses LiteLLM as its LLM backend
  - LiteLLM routes to TabbyAPI or Ollama
  
- [ ] **Initialize core memory blocks**
  - persona: Hydra's identity and capabilities
  - human: Shaun's preferences and working style
  - system_state: Current cluster status
  - active_projects: Current work in progress

- [ ] **Test basic memory persistence**
  - Start conversation, share information
  - Restart Letta container
  - Verify information persists

### Week 2: Knowledge Integration

- [ ] **Deploy Graphiti/Neo4j** (if not running)
  - Store entity relationships
  - Enable temporal queries
  
- [ ] **Import existing knowledge**
  - Parse `knowledge/*.md` files into Letta archival
  - Build initial knowledge graph from infrastructure
  
- [ ] **Connect Letta to Open WebUI**
  - Create Letta function provider
  - Enable memory-aware conversations

### Week 3: Memory Workflows

- [ ] **Create memory update workflow in n8n**
  - Trigger: End of significant interaction
  - Action: Update system_state in core memory
  
- [ ] **Implement knowledge capture**
  - When errors are resolved, store solution in archival
  - When preferences learned, update human block
  
- [ ] **Test cross-session continuity**
  - Have conversation about a project
  - End session
  - New session should know about project

**Milestone:** Conversations reference past interactions naturally.

---

## Phase 9: Agent Infrastructure (Weeks 4-6)

**Objective:** Deploy autonomous agents that can work independently on delegated tasks.

### Week 4: CrewAI Foundation

- [ ] **Deploy CrewAI on hydra-ai**
  - Close to inference for low latency
  - Uses LiteLLM for model access
  
- [ ] **Create Monitoring Crew**
  ```python
  monitoring_crew = Crew(
    agents=[
      Agent(role="System Monitor", goal="Detect anomalies"),
      Agent(role="Log Analyst", goal="Parse error patterns"),
      Agent(role="Health Reporter", goal="Summarize status")
    ],
    tasks=[
      Task(description="Analyze last hour of metrics"),
      Task(description="Check for error patterns in logs"),
      Task(description="Generate health summary")
    ]
  )
  ```

- [ ] **Create Research Crew**
  ```python
  research_crew = Crew(
    agents=[
      Agent(role="Web Researcher", goal="Find current information"),
      Agent(role="Synthesizer", goal="Combine findings"),
      Agent(role="Reporter", goal="Write clear summaries")
    ],
    tools=[SearXNG, Firecrawl, WebScraper]
  )
  ```

### Week 5: Crew Integration

- [ ] **Connect CrewAI to n8n**
  - n8n triggers crew execution
  - Crew results flow back to n8n
  
- [ ] **Create overnight research workflow**
  ```
  Trigger: 2 AM cron
  → Check Letta for pending research tasks
  → Execute research crew
  → Store results in Qdrant
  → Update Letta with summary
  → Morning notification with findings
  ```

- [ ] **Create maintenance crew**
  - Scheduled health checks
  - Proactive issue identification
  - Automated remediation suggestions

### Week 6: Agent Autonomy

- [ ] **Implement agent memory integration**
  - Agents read from Letta before tasks
  - Agents write findings to Letta after tasks
  
- [ ] **Create escalation protocols**
  - Agent confidence scoring
  - Low confidence → escalate to human
  - High confidence → execute autonomously
  
- [ ] **Test autonomous operation**
  - Queue research task before bed
  - Verify completion and quality in morning

**Milestone:** Research tasks execute overnight without intervention.

---

## Phase 10: Conversational Control Plane (Weeks 7-9)

**Objective:** Replace dashboards with natural language infrastructure control.

### Week 7: MCP Server Development

- [ ] **Create Hydra MCP Server**
  - Expose infrastructure operations as tools
  - Tools: restart_service, check_status, load_model, etc.
  
- [ ] **Implement safety layer**
  - Destructive operations require confirmation
  - Rate limiting on operations
  - Audit logging

- [ ] **Connect to Claude Desktop/Code**
  - Register MCP server
  - Test natural language commands

### Week 8: Hydra Control Plane UI

- [ ] **Initialize UI project**
  - React/Next.js foundation
  - Cyberpunk terminal aesthetic (per VISUAL-DESIGN-SPEC)
  
- [ ] **Implement core components**
  - Neural topology visualization
  - Node status cards
  - Terminal log view
  
- [ ] **Add conversational interface**
  - Chat input at center
  - Context-aware suggestions
  - Command history

### Week 9: Integration

- [ ] **Connect UI to backend services**
  - WebSocket for real-time updates
  - REST for operations
  - LiteLLM for chat
  
- [ ] **Implement voice interface** (optional)
  - Whisper for speech-to-text
  - Kokoro for text-to-speech
  - Wake word detection

**Milestone:** Control Hydra through conversation, not buttons.

---

## Phase 11: Evolution & Self-Improvement (Weeks 10-12)

**Objective:** Hydra becomes self-improving through feedback loops.

### Week 10: Documentation Synchronization

- [ ] **Create STATE.json auto-update**
  - Services report status
  - STATE.json reflects reality
  - Claude Code reads accurate state
  
- [ ] **Implement LEARNINGS.md capture**
  - After significant sessions, log insights
  - These inform future sessions
  
- [ ] **Create knowledge refresh workflow**
  - Periodically verify knowledge/*.md accuracy
  - Flag outdated information

### Week 11: Feedback Loops

- [ ] **Implement preference learning**
  - Track corrections and preferences
  - Update Letta human block automatically
  
- [ ] **Create capability expansion**
  - When encountering new requirements, document them
  - Prioritize implementation in roadmap
  
- [ ] **Implement self-diagnosis**
  - Agent analyzes own failures
  - Suggests improvements

### Week 12: Optimization

- [ ] **Inference optimization**
  - Implement RouteLLM for dynamic routing
  - Add speculative decoding with draft models
  
- [ ] **Resource optimization**
  - Analyze GPU utilization patterns
  - Adjust model loading for efficiency
  
- [ ] **Knowledge optimization**
  - Prune outdated archival memory
  - Consolidate redundant knowledge

**Milestone:** Hydra measurably improves between sessions.

---

## Future Phases (Beyond Week 12)

### Phase 12: Empire of Broken Queens Production
- Full character consistency pipeline
- Automated chapter asset generation
- Quality feedback loops

### Phase 13: Home Automation Integration
- Home Assistant connection
- Presence-aware operations
- Voice control throughout home

### Phase 14: External Intelligence
- API integrations (calendar, email, etc.)
- Proactive notifications
- Cross-platform awareness

### Phase 15: Multi-User Support
- Separate memory contexts
- Shared vs private knowledge
- Collaboration features

---

## Success Criteria by Phase

| Phase | Success Criteria |
|-------|------------------|
| 8 | Memory persists across sessions; past context recalled naturally |
| 9 | Research tasks complete overnight; findings available in morning |
| 10 | Infrastructure controlled via conversation; UI provides visibility |
| 11 | Documentation stays accurate; system measurably improves |

---

## Task Tracking

### Immediate (This Week)
- [ ] Fix any remaining TabbyAPI issues
- [ ] Deploy Letta container
- [ ] Initialize core memory blocks
- [ ] Test memory persistence

### Short-term (This Month)
- [ ] Complete Phase 8 (Memory Layer)
- [ ] Begin Phase 9 (Agent Infrastructure)
- [ ] Create monitoring crew

### Medium-term (This Quarter)
- [ ] Complete through Phase 11
- [ ] Hydra Control Plane UI functional
- [ ] Self-improving documentation

---

## Risk Mitigation

| Risk | Impact | Mitigation |
|------|--------|------------|
| Letta instability | Memory loss | PostgreSQL backups, test thoroughly |
| Agent loops | Resource exhaustion | Rate limits, max iterations, human escalation |
| NixOS rebuild failure | Node down | Always have rollback plan, test in hydra-dev first |
| Model compatibility | Inference broken | Keep previous working model, test new models offline |

---

## How Claude Code Should Use This Document

1. **At session start**: Check current phase and immediate tasks
2. **When choosing work**: Prioritize tasks aligned with current phase
3. **After completing tasks**: Update task checkboxes, move to next
4. **When blocked**: Check risk mitigation, escalate if needed
5. **At session end**: Note progress for next session

---

*This document is the implementation plan. For the "why", see VISION.md.*
*For technical details, see ARCHITECTURE.md.*
*Last updated: December 2025*
