import React, { useState } from 'react';
import { ViewState } from '../types';
import { ConversationBridge } from '../features/bridge/ConversationBridge';
import { 
  LayoutDashboard, 
  Users, 
  Briefcase, 
  Palette, 
  Database, 
  FlaskConical, 
  Server, 
  Home as HomeIcon,
  Settings,
  Bell,
  MessageSquare,
  X
} from 'lucide-react';

interface MasterLayoutProps {
  currentView: ViewState;
  onNavigate: (view: ViewState) => void;
  children: React.ReactNode;
}

export const MasterLayout: React.FC<MasterLayoutProps> = ({ currentView, onNavigate, children }) => {
  const [isMobileChatOpen, setIsMobileChatOpen] = useState(false);

  const navItems: { id: ViewState; label: string; icon: React.ReactNode }[] = [
    { id: 'MISSION', label: 'Mission', icon: <LayoutDashboard size={20} /> },
    { id: 'AGENTS', label: 'Agents', icon: <Users size={20} /> },
    { id: 'PROJECTS', label: 'Projects', icon: <Briefcase size={20} /> },
    { id: 'STUDIO', label: 'Studio', icon: <Palette size={20} /> },
    { id: 'KNOWLEDGE', label: 'Knowl.', icon: <Database size={20} /> },
    { id: 'LAB', label: 'Lab', icon: <FlaskConical size={20} /> },
    { id: 'INFRA', label: 'Infra', icon: <Server size={20} /> },
    { id: 'HOME', label: 'Home', icon: <HomeIcon size={20} /> },
  ];

  return (
    <div className="flex flex-col h-screen w-screen bg-surface-base text-neutral-200 overflow-hidden">
      
      {/* HEADER */}
      <header className="h-16 flex-none bg-surface-base border-b border-neutral-800 flex items-center justify-between px-6 z-20">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center shadow-glow-emerald">
             <span className="font-bold text-white text-lg">H</span>
          </div>
          <h1 className="text-xl font-mono font-bold tracking-tight">
            <span className="text-emerald-500">HYDRA</span>
            <span className="text-neutral-500">_COMMAND</span>
          </h1>
        </div>

        <div className="flex items-center gap-6 text-sm font-mono text-neutral-500 hidden lg:flex">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-neutral-300">4 AGENTS ACTIVE</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-amber-500">⚡ 1247W</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-neutral-300">3 NODES</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button 
             className="xl:hidden p-2 text-neutral-400 hover:text-white transition-colors"
             onClick={() => setIsMobileChatOpen(!isMobileChatOpen)}
          >
             <MessageSquare size={20} className={isMobileChatOpen ? 'text-emerald-400' : ''} />
          </button>
          <button className="p-2 text-neutral-400 hover:text-white transition-colors relative">
            <Bell size={20} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-surface-base"></span>
          </button>
          <button className="p-2 text-neutral-400 hover:text-white transition-colors">
            <Settings size={20} />
          </button>
          <div className="w-8 h-8 rounded-full bg-neutral-800 border border-neutral-700 hidden md:block"></div>
        </div>
      </header>

      {/* MAIN BODY */}
      <div className="flex flex-1 overflow-hidden relative">
        
        {/* SIDE NAV */}
        <nav className="w-16 md:w-20 flex-none bg-surface-dim border-r border-neutral-800 flex flex-col items-center py-6 gap-2 z-10 overflow-y-auto no-scrollbar">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center w-full h-16 gap-1 transition-all relative shrink-0 ${
                currentView === item.id 
                  ? 'text-emerald-400 bg-emerald-900/10' 
                  : 'text-neutral-500 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              {currentView === item.id && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-emerald-500 shadow-glow-emerald" />
              )}
              {item.icon}
              <span className="text-[10px] font-medium tracking-wide hidden md:block">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* CONTENT AREA */}
        <main className="flex-1 bg-surface-base relative overflow-hidden flex">
          <div className="flex-1 h-full overflow-hidden relative z-0">
            {children}
          </div>
          
          {/* RIGHT BRIDGE PANEL (Desktop) */}
          <aside className="hidden xl:flex h-full border-l border-neutral-800 z-10">
             <ConversationBridge />
          </aside>

          {/* MOBILE BRIDGE DRAWER */}
          {isMobileChatOpen && (
             <div className="absolute inset-0 z-50 bg-surface-base xl:hidden flex flex-col animate-slide-in">
                <div className="flex justify-end p-2 border-b border-neutral-800 bg-surface-default">
                   <button onClick={() => setIsMobileChatOpen(false)} className="p-2 text-neutral-400">
                      <X size={24} />
                   </button>
                </div>
                <div className="flex-1 overflow-hidden">
                   <ConversationBridge />
                </div>
             </div>
          )}
        </main>
      </div>
    </div>
  );
};